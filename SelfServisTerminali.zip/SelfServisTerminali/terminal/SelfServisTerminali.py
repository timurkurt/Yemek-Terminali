import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import cv2
import time
import os
import platform

try:
    import win32print
    import win32api
except ImportError:
    win32print = None
    win32api = None
    print("UYARI: 'pywin32' kütüphanesi yüklü değil. Yazıcı çalışmayacaktır.")
    print("Lütfen terminalden 'pip install pywin32' komutunu çalıştırın.")

# --- SABİTLER VE AYARLAR ---
VIDEO_DOSYA = 'yemekvideo.mp4'
FPS = 3
ARKA_PLAN_RENGI = "#FFAFAF"
ONAY_RENK = "#D5F5E3" 
IZGARA_GENISLIK, IZGARA_YUKSEKLIK = 250, 250
ANA_BUTON_GENISLIK, ANA_BUTON_YUKSEKLIK = 350, 350
GERI_BUTON_GENISLIK, GERI_BUTON_YUKSEKLIK = 150, 150
KUCUK_BUTON_GENISLIK, KUCUK_BUTON_YUKSEKLIK = 100, 100 

# Ücretli Özel İstekler ve Fiyatları
OZEL_ISTEK_FIYATLAR = {
    "İçli Kofte": 10.00,
    "Amerikan Salatası": 10.00
}

GORSEL_BUTON_DOSYALARI = {
    'buton1': '1-menu.png', 'buton2': '2-menu.png',
    'buton3': '3-menu.png',
    'geri_buton': 'back_button.png',
    'ana_buton1': 'button1.png', 'ana_buton2': 'button2.png',
    'yapim_ekibi_buton': 'info.png', 
    'sonraki_buton': 'button1.png',
    'urun_yedek': 'button1.png',
}

BASLANGIC_SECENEKLERI = {
    'baslangic_buton1': 'Restoranda',
    'baslangic_buton2': 'Paket Servis',
    'M': 'Menü Seçim Ekranı',
}
MENU_SECENEKLERI = {
    '1': 'Penne Bowl',
    '2': 'Basmati Bowl',
    '3': 'Salatalar',
}

MENU_EKSTRALAR = {
    '1': { 
        'ek1': {'isim': 'Vegan Humuslu Falafel', 'fiyat': 360.00}, 
        'ek2': {'isim': 'Dana Kasap Köfteli', 'fiyat': 410.50}, 
        'ek3': {'isim': 'Ton Balıklı', 'fiyat': 385.25}, 
        'ek4': {'isim': 'Schnitzel', 'fiyat': 380.00}, 
        'ek5': {'isim': 'Le Cordon Bleu', 'fiyat': 390.00}, 
        'ek6': {'isim': 'Tavuklu', 'fiyat': 390.00}
    },
    '2': { 
        'ek1': {'isim': 'Vegan Humuslu Falafel', 'fiyat': 360.00}, 
        'ek2': {'isim': 'Kasap Köfteli', 'fiyat': 410.50}, 
        'ek3': {'isim': 'Ton Balıklı', 'fiyat': 385.25}, 
        'ek4': {'isim': 'Schnitzel', 'fiyat': 380.00}, 
        'ek5': {'isim': 'Le Cordon Bleu', 'fiyat': 390.00}, 
        'ek6': {'isim': 'Tavuklu', 'fiyat': 390.00}
    },
    '3': { 
        'ek1': {'isim': 'Tavuklu', 'fiyat': 380.00}, 
        'ek2': {'isim': 'Tavuklu Sezar', 'fiyat': 380.00}, 
        'ek3': {'isim': 'Ton balıklı', 'fiyat': 380.00},
        'ek4': {'isim': 'Akdeniz', 'fiyat': 298.00},
    }
}

EKSTRA_VE_ICECEKLER = {
    'i1': {'isim': 'Patates Kızartması', 'fiyat': 75.00},
    'i2': {'isim': 'Mozarella Sticks', 'fiyat': 75.00},
    'i3': {'isim': 'Soğan Halkalı', 'fiyat': 75.00},
    'i4': {'isim': 'Kola', 'fiyat': 70.00},
    'i5': {'isim': 'Portakal Suyu', 'fiyat': 115.00},
    'i6': {'isim': 'Su', 'fiyat': 30.00},
}

OZEL_ISTEK = {
    "Ekstralar": ["Akdeniz Yesilligi", "Mor Lahana Tursusu", "Jalepeno Tursusu", "Sut Misir", "Salatalik", "Domates", "Humuslu Falafel", "Suzme Yogurt", "Koz Patlican", "Havuç Tarator"],
    "Ücretli Ekstralar": ["Içli Kofte (10 TL)", "Amerikan Salatasi (10TL)"]
}

class OnaySayfasi(tk.Toplevel):
    def __init__(self, kok_pencere, ana_ekran_baglanti, siparis_veri):
        super().__init__(kok_pencere)
        self.ana_ekran_ref = ana_ekran_baglanti
        self.siparis_veri = siparis_veri
        self.ozet_yazi_widget = None 
        self.attributes('-fullscreen', True)
        self.config(bg=ONAY_RENK)
        self.title("Sipariş Onay")
        self.protocol("WM_DELETE_WINDOW", self.kapat_ve_geri_don)
        self.arayuz_olustur()

    def _kaydir_yazi(self, miktar):
        if self.ozet_yazi_widget:
            self.ozet_yazi_widget.yview_scroll(miktar, "units")

    def arayuz_olustur(self):
        G, Y = self.ana_ekran_ref.ekran_genisligi, self.ana_ekran_ref.ekran_yuksekligi
        baslik_etiket = tk.Label(self, text="SİPARİŞİNİZ ALINMIŞTIR", font=("Georgia", 64, "bold"), fg="#27AE60", bg=ONAY_RENK)
        baslik_etiket.place(relx=0.5, rely=0.15, anchor=tk.CENTER)
        ozet_cerceve = tk.Frame(self, bg="#FFFFFF", bd=5, relief=tk.RAISED)
        OZET_GENISLIK = G * 0.6 
        OZET_YUKSEKLIK = Y * 0.5 
        ozet_cerceve.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=OZET_GENISLIK, height=OZET_YUKSEKLIK)
        ozet_cerceve.grid_rowconfigure(0, weight=1)    
        ozet_cerceve.grid_columnconfigure(0, weight=1) 
        self.ozet_yazi_widget = tk.Text(ozet_cerceve, font=("Georgia", 24), wrap=tk.WORD, fg="#333333", bg="#FFFFFF", relief=tk.FLAT, bd=0, padx=20, pady=20)
        self.ozet_yazi_widget.grid(row=0, column=0, sticky="nsew")
        kaydirma_alani_cerceve = tk.Frame(ozet_cerceve, bg="#F0F0F0") 
        kaydirma_alani_cerceve.grid(row=0, column=1, sticky="ns")
        kaydir_yukari_buton = tk.Button(kaydirma_alani_cerceve, text="▲", command=lambda: self._kaydir_yazi(-2), font=("Georgia", 16, "bold"), width=2, height=1, bg="#AED6F1", fg="#000000", activebackground="#85C1E9", relief=tk.RAISED, bd=2, cursor="hand2")
        kaydir_yukari_buton.pack(pady=(10, 5), padx=5, anchor=tk.N)
        kaydirma_cubugu = tk.Scrollbar(kaydirma_alani_cerceve, command=self.ozet_yazi_widget.yview)
        kaydirma_cubugu.pack(side=tk.TOP, fill=tk.Y, expand=True, padx=5)
        kaydir_asagi_buton = tk.Button(kaydirma_alani_cerceve, text="▼", command=lambda: self._kaydir_yazi(2), font=("Georgia", 16, "bold"), width=2, height=1, bg="#AED6F1", fg="#000000", activebackground="#85C1E9", relief=tk.RAISED, bd=2, cursor="hand2")
        kaydir_asagi_buton.pack(pady=(5, 10), padx=5, anchor=tk.S)
        self.ozet_yazi_widget.config(yscrollcommand=kaydirma_cubugu.set)
        ozet_yazi = self._ozet_yazi_olustur()
        self.ozet_yazi_widget.insert(tk.END, ozet_yazi)
        self.ozet_yazi_widget.config(state=tk.DISABLED)
        self.adisyonu_kaydet(ozet_yazi)
        talimat_etiket = tk.Label(self, text="♥ Bizi Tercih Ettiğiniz İçin Teşekkür ederiz ♥", font=("Georgia", 32, "italic"), fg="#34495E", bg=ONAY_RENK)
        talimat_etiket.place(relx=0.5, rely=0.80, anchor=tk.CENTER) 
        geri_foto = self.ana_ekran_ref.buton_fotolari.get('geri_normal')
        if geri_foto:
            kapat_buton = tk.Button(self, command=self.kapat_ve_geri_don, image=geri_foto, bg=ONAY_RENK, activebackground=ONAY_RENK, relief=tk.FLAT, bd=0, cursor="hand2", width=GERI_BUTON_GENISLIK, height=GERI_BUTON_YUKSEKLIK)
            kapat_buton.image = geri_foto
            kapat_buton.place(relx=0.02, rely=0.02, anchor=tk.NW) 
        else:
            kapat_buton = tk.Button(self, text="<< Geri Dön", command=self.kapat_ve_geri_don, font=("Georgia", 20, "bold"), bg="#E74C3C", fg="white", activebackground="#C0392B", relief=tk.RAISED, bd=4, cursor="hand2")
            kapat_buton.place(relx=0.02, rely=0.02, anchor=tk.NW)

    def _ozet_yazi_olustur(self):
        ana_menuler = self.siparis_veri.get('ana_menuler_toplami', [])
        baslangic_secenek = self.siparis_veri['baslangic_secenek']
        tum_ekstralar = self.siparis_veri.get('tum_ekstralar', [])
        ozel_istekler = self.siparis_veri.get('ozel_istekler', []) 
        toplam_tutar = self.siparis_veri.get('toplam_tutar', 0.00) 
        ana_menuler_ozet = ", ".join(ana_menuler) if ana_menuler else "Menü Seçilmedi"
        
        guncel_tarih = time.strftime("%d.%m.%Y %H:%M")

        nihai_ozet = [
            f"Tarih: {guncel_tarih}",
            f"Siparis No: #{int(time.time()) % 10000}",
            "---------------------------------",
            f"Alis Sekli: {baslangic_secenek}",
            f"Menü: {ana_menuler_ozet}",
            "---------------------------------",
            "Secilen Tum Urunler:",
        ]
        if tum_ekstralar:
            for ekstra in tum_ekstralar:
                nihai_ozet.append(f" - {ekstra}") 
        else:
            nihai_ozet.append(" - Hicbir Cesit Secilmedi")
        if ozel_istekler:
            nihai_ozet.append("---------------------------------")
            nihai_ozet.append("OZEL ISTEKLER:")
            for istek in ozel_istekler:
                nihai_ozet.append(f" * {istek}")
        nihai_ozet.append("\n\n")
        nihai_ozet.append(f"Toplam Tutar: {toplam_tutar:.2f} TL") 
        nihai_ozet.append("Odeme kasada yapilacaktir.")
        nihai_ozet.append("Bizi tercih ettiginiz icin tesekkurler.")
        nihai_ozet.append("Timur Kurt/Recep Demir IGU-BT")
        return "\n".join(nihai_ozet)

    def adisyonu_kaydet(self, icerik):
        try:
            with open("adisyon_kayitlari.txt", "a", encoding="utf-8") as f:
                f.write("==================================================\n")
                f.write(icerik)
                f.write("\n==================================================\n\n")
        except Exception as e:
            print(f"HATA: Dosya kaydı başarısız: {e}")
        if win32print:
            try:
                yazici_adi = win32print.GetDefaultPrinter()
                hPrinter = win32print.OpenPrinter(yazici_adi)
                try:
                    hJob = win32print.StartDocPrinter(hPrinter, 1, ("Kiosk Siparis Fisi", None, "RAW"))
                    try:
                        win32print.StartPagePrinter(hPrinter)
                        RESET = b'\x1b\x40'       
                        KESME = b'\x1d\x56\x42\x00' 
                        yazilacak_veri = icerik.encode("cp857", errors="replace")
                        raw_data = RESET + yazilacak_veri + b"\n\n\n" + KESME
                        win32print.WritePrinter(hPrinter, raw_data)
                        win32print.EndPagePrinter(hPrinter)
                    finally:
                        win32print.EndDocPrinter(hPrinter)
                finally:
                    win32print.ClosePrinter(hPrinter)
            except Exception as e:
                print(f"YAZICI HATASI: {e}")

    def kapat_ve_geri_don(self):
        self.ana_ekran_ref.videoya_geri_don()
        self.destroy()

class YanUrunEkrani(tk.Toplevel):
    def __init__(self, kok_pencere, ana_ekran_baglanti, siparis_veri, menuye_donus_penceresi):
            super().__init__(kok_pencere)
            self.ana_ekran_ref = ana_ekran_baglanti 
            self.menuye_donus_ref = menuye_donus_penceresi 
            self.siparis_veri = siparis_veri
            self.mevcut_tutar = siparis_veri['toplam_tutar']
            self.ekstra_secimleri = {key: 0 for key in EKSTRA_VE_ICECEKLER.keys()}
            self.ekstra_widgetler = {}
            self.attributes('-fullscreen', True)
            self.config(bg=ARKA_PLAN_RENGI)
            self.title("Ekstra ve İçecek Seçimi")
            self.arayuz_olustur()
            self.protocol("WM_DELETE_WINDOW", self.geri_don)

    def arayuz_olustur(self):
        G, Y = self.ana_ekran_ref.ekran_genisligi, self.ana_ekran_ref.ekran_yuksekligi
        self.baslik_etiket = tk.Label(self, text="İçecek ve Ekstra Ürünler", fg="#333333", font=("Georgia", 48, "bold"), bg=ARKA_PLAN_RENGI)
        self.baslik_etiket.place(relx=0.5, rely=0.15, anchor=tk.CENTER)
        icerik_cerceve = tk.Frame(self, bg=ARKA_PLAN_RENGI)
        icerik_cerceve.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=G*0.8, height=Y*0.6)
        buton_izgara_cerceve = tk.Frame(icerik_cerceve, bg=ARKA_PLAN_RENGI)
        buton_izgara_cerceve.pack(pady=20, fill=tk.BOTH, expand=True) 
        secenekler = EKSTRA_VE_ICECEKLER
        for i, (anahtar, veri) in enumerate(secenekler.items()): 
            satir = i // 3
            sutun = i % 3
            isim = veri['isim']
            fiyat = veri['fiyat']
            gorunur_yazi = f"{isim} ({fiyat:.2f} TL)"
            ekstra_urun_cerceve = tk.Frame(buton_izgara_cerceve, bg="#FFFFFF", bd=2, relief=tk.RAISED)
            ekstra_urun_cerceve.grid(row=satir, column=sutun, padx=15, pady=10, sticky="ew")
            isim_etiket = tk.Label(ekstra_urun_cerceve, text=gorunur_yazi, font=("Georgia", 18, "bold"), bg="#FFFFFF", fg="#333333", anchor=tk.W)
            isim_etiket.pack(side=tk.TOP, padx=10, pady=5, fill=tk.X) 
            miktar_cerceve = tk.Frame(ekstra_urun_cerceve, bg="#FFFFFF")
            miktar_cerceve.pack(side=tk.BOTTOM, padx=5, pady=10)
            buton_eksi = tk.Button(miktar_cerceve, text=" - ", command=(lambda k=anahtar: self.ekstra_azalt(k)), font=("Georgia", 20, "bold"), width=3, height=1, bg="#E74C3C", fg="white", activebackground="#C0392B", relief=tk.RAISED, cursor="hand2")
            buton_eksi.pack(side=tk.LEFT, padx=5)
            miktar_etiket = tk.Label(miktar_cerceve, text="0", font=("Georgia", 20, "bold"), width=3, bg="#F0F0F0", fg="#333333")
            miktar_etiket.pack(side=tk.LEFT, padx=5)
            buton_arti = tk.Button(miktar_cerceve, text=" + ", command=(lambda k=anahtar: self.ekstra_arttir(k)), font=("Georgia", 20, "bold"), width=3, height=1, bg="#2ECC71", fg="white", activebackground="#27AE60", relief=tk.RAISED, cursor="hand2")
            buton_arti.pack(side=tk.LEFT, padx=5)
            self.ekstra_widgetler[anahtar] = {'miktar_etiket': miktar_etiket}
        for c in range(3):
            buton_izgara_cerceve.grid_columnconfigure(c, weight=1)
        self.tutar_etiket = tk.Label(self, text=f"Mevcut Tutar: {self.mevcut_tutar:.2f} TL", font=("Georgia", 32, "bold"), bg=ARKA_PLAN_RENGI, fg="#1C2833")
        self.tutar_etiket.place(relx=0.5, rely=0.75, anchor=tk.CENTER)
        buton_cercevesi = tk.Frame(self, bg=ARKA_PLAN_RENGI)
        buton_cercevesi.place(relx=0.5, rely=0.9, anchor=tk.CENTER, width=G*0.8)
        geri_buton = tk.Button(buton_cercevesi, text="Geri Dön (Menüye)", command=self.geri_don, font=("Georgia", 28, "bold"), bg="#F39C12", fg="white", activebackground="#D35400", relief=tk.RAISED, bd=4, cursor="hand2")
        geri_buton.pack(side=tk.LEFT, padx=8, fill=tk.X, expand=True)
        tamamla_buton = tk.Button(buton_cercevesi, text="Siparişi Tamamla", command=self.siparisi_tamamla, font=("Georgia", 32, "bold"), bg="#2ECC71", fg="white", activebackground="#27AE60", relief=tk.RAISED, bd=4, cursor="hand2")
        tamamla_buton.pack(side=tk.RIGHT, padx=10, fill=tk.X, expand=True)
    
    def tutari_guncelle(self):
        yeni_ekstra_tutar = 0.0
        for anahtar, miktar in self.ekstra_secimleri.items():
            if miktar > 0:
                yeni_ekstra_tutar += miktar * EKSTRA_VE_ICECEKLER[anahtar]['fiyat']
        final_tutar = self.mevcut_tutar + yeni_ekstra_tutar
        self.tutar_etiket.config(text=f"TOPLAM TUTAR: {final_tutar:.2f} TL")
        return final_tutar

    def ekstra_miktar_etiketi_guncelle(self, anahtar, miktar):
        if anahtar in self.ekstra_widgetler:
            self.ekstra_widgetler[anahtar]['miktar_etiket'].config(text=str(miktar))
            self.tutari_guncelle()

    def ekstra_arttir(self, anahtar):
        mevcut_miktar = self.ekstra_secimleri.get(anahtar, 0)
        if mevcut_miktar < 20: 
            yeni_miktar = mevcut_miktar + 1
            self.ekstra_secimleri[anahtar] = yeni_miktar
            self.ekstra_miktar_etiketi_guncelle(anahtar, yeni_miktar)
        elif mevcut_miktar == 20:
            messagebox.showwarning("Uyarı", "Bir üründen maksimum 20 adet seçebilirsiniz.", parent=self)

    def ekstra_azalt(self, anahtar):
        mevcut_miktar = self.ekstra_secimleri.get(anahtar, 0)
        if mevcut_miktar > 0:
            yeni_miktar = mevcut_miktar - 1
            self.ekstra_secimleri[anahtar] = yeni_miktar
            self.ekstra_miktar_etiketi_guncelle(anahtar, yeni_miktar)

    def geri_don(self):
        self.menuye_donus_ref.deiconify() 
        self.destroy() 

    def siparisi_tamamla(self):
        final_tutar = self.tutari_guncelle() 
        ekstra_ozet_liste = []
        ekstra_sayisi = 0
        for anahtar, miktar in self.ekstra_secimleri.items():
            if miktar > 0:
                veri = EKSTRA_VE_ICECEKLER[anahtar]
                isim = veri['isim']
                fiyat = veri['fiyat']
                urun_tutar = miktar * fiyat
                ekstra_ozet_liste.append(f"{miktar} x {isim} (Ekstra) - {urun_tutar:.2f} TL (Adet: {fiyat:.2f} TL)")
                ekstra_sayisi += miktar
        final_siparis_veri = self.siparis_veri.copy()
        final_siparis_veri['tum_ekstralar'].extend(ekstra_ozet_liste) 
        final_siparis_veri['toplam_tutar'] = final_tutar 
        onay = messagebox.askyesno("Devam et", f"Bir bakalım...\nToplam Tutar: {final_tutar:.2f} TL\n{ekstra_sayisi} adet ekstra seçmişsin bi bak bence.\nYa da kasaya git seçim senin.", parent=self)
        if onay:
            self.ana_ekran_ref.siparis_gecmisi.append(final_siparis_veri)
            self.menuye_donus_ref._onay_goster_ve_geri_don(final_siparis_veri) 
            self.destroy()

class EkstraBilgiSayfasi(tk.Toplevel):
    def __init__(self, kok_pencere, ana_ekran_baglanti):
        super().__init__(kok_pencere)
        self.ana_ekran_ref = ana_ekran_baglanti
        self.attributes('-fullscreen', True)
        self.config(bg="#E0FFFF") 
        self.title("Yapım Ekibi")
        self.arayuz_olustur() 
        self.protocol("WM_DELETE_WINDOW", self.kapat_ve_geri_don)

    def arayuz_olustur(self):
        tk.Label(self, text="Yapan Topluluk", font=("Georgia", 64, "bold"), fg="#006666", bg="#E0FFFF").place(relx=0.5, rely=0.2, anchor=tk.CENTER)
        tk.Label(self, text="Abarttık sanki hadi kişiler diyelim", font=("Georgia", 20, "bold"), fg="#73a8a8", bg="#E0FFFF").place(relx=0.5, rely=0.3, anchor=tk.CENTER)
        tk.Label(self, text="Timur Kurt - 250118073 (Katkı: Backend, Editör)", font=("Georgia", 40), fg="#34495E", bg="#E0FFFF").place(relx=0.5, rely=0.45, anchor=tk.CENTER)
        tk.Label(self, text="Recep Demir - 250118065 (Katkı: Frontend, fotoğraf)", font=("Georgia", 40), fg="#34495E", bg="#E0FFFF").place(relx=0.5, rely=0.55, anchor=tk.CENTER)
        tk.Label(self, text="İstanbul Gelişim Üniversitesi - Bilgisayar Teknolojisi", font=("Georgia", 28, "italic"), fg="#7F8C8D", bg="#E0FFFF").place(relx=0.5, rely=0.68, anchor=tk.CENTER)
        kapat_buton = tk.Button(self, text="Geri Dön", command=self.kapat_ve_geri_don, font=("Georgia", 36, "bold"), bg="#F08080", fg="white", activebackground="#CD5C5C", relief=tk.RAISED, bd=4, cursor="hand2")
        kapat_buton.place(relx=0.5, rely=0.85, anchor=tk.CENTER, width=650, height=100)
    
    def kapat_ve_geri_don(self):
        self.ana_ekran_ref.videoya_geri_don()
        self.destroy()
            
class MenuSecimPenceresi(tk.Toplevel):
    def __init__(self, kok_pencere, ana_ekran_baglanti):
        super().__init__(kok_pencere)
        self.transient(kok_pencere)
        self.ana_ekran_ref = ana_ekran_baglanti
        self.attributes('-fullscreen', True)
        self.lift()
        self.config(bg=ARKA_PLAN_RENGI)
        
        self.buton_widgetler = {}
        self.buton_fotolari = ana_ekran_baglanti.buton_fotolari
        self.secili_ana_menu = None 
        self.tum_menu_secimleri = {} 
        self.ekstra_buton_widgetler = {} 
        self.onay_buton = None
        self.ozel_istek_secimleri = {} # Çoklu seçim için BooleanVar tutan sözlük

        self.izgara_butonlari_olustur()
        self.sag_paneli_olustur() 
        
        self.protocol("WM_DELETE_WINDOW", self.kapat_ve_videoya_don)
        
    def _buton_stili_getir(self, anahtar, yazi):
        parametreler = {'relief': tk.FLAT, 'bd': 0}
        if anahtar.startswith('secenek'):
            parametreler.update({
                "text": yazi,
                "font": ("Georgia", 18, "bold"), 
                "bg": "#F0F0F0", 
                "fg": "#333333", 
                "relief": tk.RAISED, 
                "bd": 2,
                "width": 18, 
                "height": 2, 
                "activebackground": "#DDDDDD", 
                "cursor": "hand2"
            })
        elif anahtar == 'geri':
            if 'geri_normal' in self.buton_fotolari:
                parametreler.update({'image': self.buton_fotolari['geri_normal'], 'bg': ARKA_PLAN_RENGI, 'activebackground': ARKA_PLAN_RENGI})
            else:
                parametreler.update({'text': "<< Geri Dön", 'font': ("Georgia", 18, "bold"), 'fg': "#5C5C5C", 'bg': ARKA_PLAN_RENGI, 'activebackground': "#D3A9A9"})
        return parametreler

    def izgara_butonlari_olustur(self):
        buton_ozellikleri = {
            'secenek1': ("1", MENU_SECENEKLERI['1']), 'secenek2': ("2", MENU_SECENEKLERI['2']),
            'secenek3': ("3", MENU_SECENEKLERI['3']),
            'geri': (None, "Geri")
        }
        for anahtar, (secenek_id, yazi) in buton_ozellikleri.items():
            parametreler = self._buton_stili_getir(anahtar, yazi)
            buton = tk.Button(self, **parametreler)
            self.buton_widgetler[anahtar] = buton
            
        G, Y = self.ana_ekran_ref.ekran_genisligi, self.ana_ekran_ref.ekran_yuksekligi
        MERKEZ_SOL_X = G * 0.30 
        IZGARA_BOSLUK_X = 280 
        
        x1 = MERKEZ_SOL_X - IZGARA_BOSLUK_X
        x2 = MERKEZ_SOL_X
        x3 = MERKEZ_SOL_X + IZGARA_BOSLUK_X 
        
        y_baslik = Y * 0.10 
        y_satir1 = Y * 0.25 
        y_geri = Y - 80 
        
        self.buton_pozisyonlari = {
            'secenek1': (x1, y_satir1),
            'secenek2': (x2, y_satir1),
            'secenek3': (x3, y_satir1),
            'geri': (G - 150, y_geri), 
            'baslik': (MERKEZ_SOL_X, y_baslik)
        }
        
        for anahtar, (secenek_id, yazi) in buton_ozellikleri.items():
            if anahtar == 'geri':
                self.buton_widgetler[anahtar].config(command=self.kapat_ve_videoya_don)
            else:
                self.buton_widgetler[anahtar].config(command=(lambda o=secenek_id, k=anahtar: self.ana_menu_sec(o, self.buton_widgetler[k])))
        
        self.ekstralar_cerceve = tk.Frame(self, bg=ARKA_PLAN_RENGI)
        self.ekstralar_cerceve.place(x=50, y=Y * 0.45, anchor=tk.NW, width=G*0.6) 
        
        self.ekstralar_baslik_etiket = tk.Label(self.ekstralar_cerceve, text="Menü Ekstraları", fg="#333333", font=("Georgia", 24, "bold"), bg=ARKA_PLAN_RENGI)
        self.ekstralar_baslik_etiket.pack(pady=(0, 10), anchor=tk.W)
        
        self.onay_buton = tk.Button(self, text="Önce Seçim Yap", command=self.siparis_onayla, font=("Georgia", 32, "bold"), bg="#CCCCCC", fg="#666666", relief=tk.RAISED, state=tk.DISABLED, bd=4, cursor="hand2")
        self.onay_buton.place(x=MERKEZ_SOL_X, rely=0.90, anchor=tk.CENTER, width=600, height=80)
        
        self.baslik_etiket = tk.Label(self, text="Önce Menü", fg="#333333", font=("Georgia", 48, "bold"), bg=ARKA_PLAN_RENGI)
        self.baslik_etiket.place(x=self.buton_pozisyonlari['baslik'][0], y=self.buton_pozisyonlari['baslik'][1], anchor=tk.CENTER)
        
        for anahtar, (x, y) in self.buton_pozisyonlari.items():
            if anahtar not in ['baslik']:
                demirleme_tipi = tk.E if anahtar == 'geri' else tk.CENTER
                self.buton_widgetler[anahtar].place(x=x, y=y, anchor=demirleme_tipi)

    def sag_paneli_olustur(self):
        """Sağ tarafta Checkbutton ile çoklu seçim yapısı oluşturur."""
        G, Y = self.ana_ekran_ref.ekran_genisligi, self.ana_ekran_ref.ekran_yuksekligi
        
        ana_panel = tk.Frame(self, bg="#FFFFFF", bd=2, relief=tk.SUNKEN)
        ana_panel.place(relx=0.65, rely=0.15, relwidth=0.33, relheight=0.70)

        for grup_basligi, secenekler in OZEL_ISTEK.items():
            baslik_lbl = tk.Label(ana_panel, text=grup_basligi, font=("Georgia", 16, "bold"), bg="#3498DB", fg="white", anchor="w", padx=10)
            baslik_lbl.pack(fill="x", pady=(15, 5))
            
            for secenek in secenekler:
                var = tk.BooleanVar(value=False)
                self.ozel_istek_secimleri[secenek] = var
                
                # Fiyat varsa metne ekle
                fiyat = OZEL_ISTEK_FIYATLAR.get(secenek, 0)
                gorunur_metin = f"{secenek} (+{fiyat:.2f} TL)" if fiyat > 0 else secenek

                cb = tk.Checkbutton(
                    ana_panel, 
                    text=gorunur_metin,
                    variable=var, 
                    font=("Georgia", 12),
                    bg="#ECF0F1",
                    activebackground="#BDC3C7",
                    selectcolor="#FFFFFF", # Seçildiğinde içini beyaz yap
                    bd=1,
                    relief=tk.FLAT,
                    anchor="w",
                    padx=10
                )
                cb.pack(pady=2, padx=5, fill="x")

    def menu_gorseli_guncelle(self, menu_id):
        pass 
        
    def ekstra_butonlari_olustur(self, menu_id):
        for widget in self.ekstralar_cerceve.winfo_children():
            widget.destroy()
            
        self.ekstralar_baslik_etiket = tk.Label(self.ekstralar_cerceve, text="Spesyellerimiz:", fg="#333333", font=("Georgia", 20, "bold"), bg=ARKA_PLAN_RENGI)
        self.ekstralar_baslik_etiket.pack(anchor=tk.W, pady=(0, 10))
        
        self.ekstra_buton_widgetler = {}
        buton_izgara_cerceve = tk.Frame(self.ekstralar_cerceve, bg=ARKA_PLAN_RENGI)
        buton_izgara_cerceve.pack(anchor=tk.W) 
        
        secenekler = MENU_EKSTRALAR.get(menu_id, {})
        if menu_id not in self.tum_menu_secimleri:
            self.tum_menu_secimleri[menu_id] = {anahtar: 0 for anahtar in secenekler.keys()}
        
        mevcut_secimler = self.tum_menu_secimleri[menu_id] 
        
        for i, (anahtar, veri) in enumerate(secenekler.items()): 
            satir = i // 2
            sutun = i % 2
            isim = veri['isim']
            fiyat = veri['fiyat']
            gorunur_yazi = f"{isim}\n({fiyat:.2f} TL)" 
            
            ekstra_urun_cerceve = tk.Frame(buton_izgara_cerceve, bg="#FFFFFF", bd=2, relief=tk.RAISED)
            ekstra_urun_cerceve.grid(row=satir, column=sutun, padx=10, pady=8, sticky="ew")
            
            isim_etiket = tk.Label(ekstra_urun_cerceve, text=gorunur_yazi, font=("Georgia", 12, "bold"), bg="#FFFFFF", fg="#333333", anchor=tk.W, width=20)
            isim_etiket.pack(side=tk.LEFT, padx=(5, 5), pady=5) 
            
            buton_eksi = tk.Button(ekstra_urun_cerceve, text="-", command=(lambda k=anahtar, m=menu_id: self.ekstra_azalt(m, k)), font=("Arial", 14, "bold"), width=2, bg="#E74C3C", fg="white", relief=tk.RAISED)
            buton_eksi.pack(side=tk.LEFT, padx=2)
            
            miktar = mevcut_secimler.get(anahtar, 0)
            miktar_etiket = tk.Label(ekstra_urun_cerceve, text=str(miktar), font=("Arial", 14, "bold"), width=2, bg="#F0F0F0")
            miktar_etiket.pack(side=tk.LEFT, padx=2)
            
            buton_arti = tk.Button(ekstra_urun_cerceve, text="+", command=(lambda k=anahtar, m=menu_id: self.ekstra_arttir(m, k)), font=("Arial", 14, "bold"), width=2, bg="#2ECC71", fg="white", relief=tk.RAISED)
            buton_arti.pack(side=tk.LEFT, padx=2)
            
            self.ekstra_buton_widgetler[anahtar] = {'miktar_etiket': miktar_etiket, 'cerceve': ekstra_urun_cerceve}

    def ekstra_miktar_etiketi_guncelle(self, anahtar, miktar):
        if anahtar in self.ekstra_buton_widgetler and 'miktar_etiket' in self.ekstra_buton_widgetler[anahtar]:
            self.ekstra_buton_widgetler[anahtar]['miktar_etiket'].config(text=str(miktar))

    def ekstra_arttir(self, menu_id, anahtar):
        if menu_id not in self.tum_menu_secimleri: return
        mevcut_miktar = self.tum_menu_secimleri[menu_id].get(anahtar, 0)
        if mevcut_miktar < 9: 
            yeni_miktar = mevcut_miktar + 1
            self.tum_menu_secimleri[menu_id][anahtar] = yeni_miktar
            self.ekstra_miktar_etiketi_guncelle(anahtar, yeni_miktar)
        else:
            messagebox.showwarning("Uyarı", "Maksimum sınıra ulaştınız.", parent=self)

    def ekstra_azalt(self, menu_id, anahtar):
        if menu_id not in self.tum_menu_secimleri: return
        mevcut_miktar = self.tum_menu_secimleri[menu_id].get(anahtar, 0)
        if mevcut_miktar > 0:
            yeni_miktar = mevcut_miktar - 1
            self.tum_menu_secimleri[menu_id][anahtar] = yeni_miktar
            self.ekstra_miktar_etiketi_guncelle(anahtar, yeni_miktar)

    def ana_menu_sec(self, secenek_id, buton_widget):
        for anahtar in self.buton_widgetler:
            if anahtar.startswith('secenek'):
                self.buton_gorselini_sifirla(self.buton_widgetler[anahtar], anahtar) 
        buton_widget.config(bg="#3498DB", fg="#FFFFFF", relief=tk.SUNKEN)
        self.secili_ana_menu = secenek_id
        self.ekstra_butonlari_olustur(secenek_id) 
        self.onay_buton.config(state=tk.NORMAL, bg="#2ECC71", fg="#FFFFFF", text=f"Devam et")

    def siparis_onayla(self):
        if not self.secili_ana_menu:
            messagebox.showwarning("Uyarı", "Lütfen bir menü seçiniz.", parent=self)
            return
            
        tum_secili_ekstralar_liste = []
        secilen_ana_menuler_isimleri = []
        toplam_tutar = 0.0
        
        for menu_id, ana_menu_isim in MENU_SECENEKLERI.items():
            mevcut_ekstralar_harita = MENU_EKSTRALAR.get(menu_id, {})
            kayitli_secimler = self.tum_menu_secimleri.get(menu_id, {})
            secili_ekstralar_bu_menu_icin = []
            for anahtar, veri in mevcut_ekstralar_harita.items(): 
                miktar = kayitli_secimler.get(anahtar, 0)
                if miktar > 0:
                    isim = veri['isim']
                    fiyat = veri['fiyat'] 
                    urun_tutar = miktar * fiyat 
                    toplam_tutar += urun_tutar 
                    urun_miktar_ile = f"{miktar} x {isim} ({ana_menu_isim}) - {urun_tutar:.2f} TL"
                    tum_secili_ekstralar_liste.append(urun_miktar_ile)
                    secili_ekstralar_bu_menu_icin.append(urun_miktar_ile)
            
            if secili_ekstralar_bu_menu_icin:
                secilen_ana_menuler_isimleri.append(ana_menu_isim)
        
        if self.secili_ana_menu and not secilen_ana_menuler_isimleri:
             secilen_ana_menuler_isimleri.append(MENU_SECENEKLERI[self.secili_ana_menu])

        # Çoklu Seçilen Özel İstekleri ve Fiyatlarını İşleme
        ozel_istekler_listesi = []
        for urun_adi, var in self.ozel_istek_secimleri.items():
            if var.get():
                ekstra_fiyat = OZEL_ISTEK_FIYATLAR.get(urun_adi, 0)
                if ekstra_fiyat > 0:
                    toplam_tutar += ekstra_fiyat
                    ozel_istekler_listesi.append(f"{urun_adi} (+{ekstra_fiyat:.2f} TL)")
                else:
                    ozel_istekler_listesi.append(urun_adi)

        siparis_veri = {
            'baslangic_secenek': BASLANGIC_SECENEKLERI.get(self.ana_ekran_ref.secili_baslangic_secenek, 'Bilinmiyor'),
            'ana_menuler_toplami': secilen_ana_menuler_isimleri, 
            'tum_ekstralar': tum_secili_ekstralar_liste, 
            'ozel_istekler': ozel_istekler_listesi, 
            'toplam_tutar': toplam_tutar, 
            'zaman_damgasi': time.time(),
        }
        
        self.withdraw() 
        yan_urun = YanUrunEkrani(self.master, self.ana_ekran_ref, siparis_veri, self)
        yan_urun.lift()

    def _onay_goster_ve_geri_don(self, final_siparis_veri):
        self.onay_buton.config(text="Sipariş Alındı...", bg="#1ABC9C", state=tk.DISABLED)
        OnaySayfasi(self.master, self.ana_ekran_ref, final_siparis_veri)
        self.destroy()

    def buton_gorselini_sifirla(self, buton_widget, buton_anahtar):
        if buton_anahtar.startswith('secenek'):
            secenek_id = buton_anahtar[-1] 
            buton_widget.config(**self._buton_stili_getir(buton_anahtar, MENU_SECENEKLERI[secenek_id]))

    def kapat_ve_videoya_don(self):
        self.ana_ekran_ref.videoya_geri_don()
        self.destroy()

class KioskUygulamasi:
    def __init__(self, kok_pencere):
        self.ana = kok_pencere
        kok_pencere.attributes('-fullscreen', True)
        self.ekran_genisligi = kok_pencere.winfo_screenwidth()
        self.ekran_yuksekligi = kok_pencere.winfo_screenheight()
        self.secili_baslangic_secenek = None
        self.ekstra_bilgi_aktif = False 
        self.secili_menu_secenek = None
        self.siparis_gecmisi = [] 
        self.zaman_asimi_job = None
        self.uyari_penceresi = None
        self.uyari_geri_sayim_job = None
        self.tuval = tk.Canvas(kok_pencere, width=self.ekran_genisligi, height=self.ekran_yuksekligi, highlightthickness=0, bg="black")
        self.tuval.pack()
        self.yakalama = cv2.VideoCapture(VIDEO_DOSYA)
        if not self.yakalama.isOpened():
            messagebox.showerror("Hata", f"Video Yüklenemedi: '{VIDEO_DOSYA}'")
            kok_pencere.destroy(); return
        self.video_oynuyor, self.menu_aktif = True, False
        self.buton_widgetler, self.buton_fotolari = {}, {}
        self.resimli_buton_kullan = True
        self.gorselleri_yukle()
        self.butonlari_olustur()
        self.tuval.bind("<Button-1>", self.tiklama_isle)
        kok_pencere.protocol("WM_DELETE_WINDOW", self._kapatilirken)
        kok_pencere.bind_all("<Button-1>", self.aktivite_algilandi)
        kok_pencere.bind_all("<Key>", self.aktivite_algilandi)
        self.kareyi_guncelle()

    def aktivite_algilandi(self, event=None):
        if self.menu_aktif and not self.video_oynuyor:
            self.zaman_asimi_sifirla()

    def zaman_asimi_sifirla(self):
        if self.zaman_asimi_job:
            self.ana.after_cancel(self.zaman_asimi_job)
        if self.uyari_penceresi:
            self.uyari_penceresi.destroy()
            self.uyari_penceresi = None
        self.zaman_asimi_job = self.ana.after(20000, self.uyari_goster)

    def uyari_goster(self):
        if not self.menu_aktif: return
        self.uyari_penceresi = tk.Toplevel(self.ana)
        self.uyari_penceresi.title("Uyarı")
        x = (self.ekran_genisligi // 2) - 300
        y = (self.ekran_yuksekligi // 2) - 200
        self.uyari_penceresi.geometry(f"600x400+{x}+{y}")
        self.uyari_penceresi.config(bg="#E74C3C")
        self.uyari_penceresi.attributes('-topmost', True)
        self.uyari_penceresi.overrideredirect(True) 
        tk.Label(self.uyari_penceresi, text="ORADA MISIN ???", font=("Georgia", 32, "bold"), fg="white", bg="#E74C3C").pack(pady=(40, 20))
        self.uyari_geri_sayim_label = tk.Label(self.uyari_penceresi, text="5", font=("Georgia", 80, "bold"), fg="yellow", bg="#E74C3C")
        self.uyari_geri_sayim_label.pack()
        tk.Label(self.uyari_penceresi, text="Yoksa kapatmak zorunda kalıcam", font=("Georgia", 24), fg="white", bg="#E74C3C").pack(pady=20)
        tk.Label(self.uyari_penceresi, text="Eğer oradaysan ekrana dokun", font=("Georgia", 16, "italic"), fg="white", bg="#E74C3C").pack(pady=10)
        self.geri_sayim(5)

    def geri_sayim(self, saniye):
        if not self.uyari_penceresi: return
        self.uyari_geri_sayim_label.config(text=str(saniye))
        if saniye > 0:
            self.uyari_geri_sayim_job = self.ana.after(1000, lambda: self.geri_sayim(saniye - 1))
        else:
            if self.uyari_penceresi:
                self.uyari_penceresi.destroy()
                self.uyari_penceresi = None
            self.videoya_geri_don()

    def gorselleri_yukle(self):
        self.buton_fotolari = {}
        self.resimli_buton_kullan = True
        try:
            self.buton_fotolari['aktif_efekt'] = ImageTk.PhotoImage(Image.open('button2.png').resize((IZGARA_GENISLIK, IZGARA_YUKSEKLIK)))
        except (FileNotFoundError, Exception):
            pass
        for i, anahtar in enumerate(['buton1', 'buton2', 'buton3'], 1):
            normal_dosya = GORSEL_BUTON_DOSYALARI.get(anahtar)
            if not normal_dosya: continue
            try:
                gorsel = Image.open(normal_dosya).resize((IZGARA_GENISLIK, IZGARA_YUKSEKLIK))
                self.buton_fotolari[f'secenek{i}_normal'] = ImageTk.PhotoImage(gorsel)
            except (FileNotFoundError, Exception):
                pass
        self._tekil_resim_yukle('geri_buton', 'geri_normal', GERI_BUTON_GENISLIK, GERI_BUTON_YUKSEKLIK, "Geri Dön", self.buton_fotolari)
        self._tekil_resim_yukle('ana_buton1', 'ana_buton1_normal', ANA_BUTON_GENISLIK, ANA_BUTON_YUKSEKLIK, "Başlat Butonu 1", self.buton_fotolari)
        self._tekil_resim_yukle('ana_buton2', 'ana_buton2_normal', ANA_BUTON_GENISLIK, ANA_BUTON_YUKSEKLIK, "Başlat Butonu 2", self.buton_fotolari)
        self._tekil_resim_yukle('yapim_ekibi_buton', 'ekstra_bilgi_normal', KUCUK_BUTON_GENISLIK, KUCUK_BUTON_YUKSEKLIK, "Yapım Ekibi Butonu", self.buton_fotolari)

    def _tekil_resim_yukle(self, dosya_anahtari, foto_anahtari, g, y, isim, foto_sozluk):
        dosya = GORSEL_BUTON_DOSYALARI.get(dosya_anahtari)
        if dosya:
            try:
                gorsel = Image.open(dosya).resize((g, y))
                foto_sozluk[foto_anahtari] = ImageTk.PhotoImage(gorsel)
            except Exception as e:
                print(f"UYARI: {dosya} yüklenemedi: {e}")

    def butonlari_olustur(self):
        MERKEZ_X, MERKEZ_Y = self.ekran_genisligi / 2, self.ekran_yuksekligi / 2
        baslangic_y = self.ekran_yuksekligi * 2
        BUTON_ARASI_BOSLUK = 150 
        X1 = MERKEZ_X - (BUTON_ARASI_BOSLUK / 2) - (ANA_BUTON_GENISLIK / 2)
        X2 = MERKEZ_X + (BUTON_ARASI_BOSLUK / 2) + (ANA_BUTON_GENISLIK / 2)
        hedef_y = MERKEZ_Y
        KOSESEL_MARJIN = 50 
        X_KOSESI = self.ekran_genisligi - KUCUK_BUTON_GENISLIK/2 - KOSESEL_MARJIN
        Y_KOSESI = self.ekran_yuksekligi - KUCUK_BUTON_YUKSEKLIK/2 - KOSESEL_MARJIN
        
        parametreler1 = {'command': lambda: self.secenek_sec("baslangic_buton1", self.buton_widgetler['baslangic_buton1']), 'relief': tk.FLAT, 'bd': 0}
        if 'ana_buton1_normal' in self.buton_fotolari:
            parametreler1.update({'image': self.buton_fotolari['ana_buton1_normal'], 'bg': ARKA_PLAN_RENGI, 'activebackground': ARKA_PLAN_RENGI})
        else:
            parametreler1.update({'text': BASLANGIC_SECENEKLERI['baslangic_buton1'], 'font': ("Georgia", 28, "bold"), 'fg': "#3A3A3A", 'bg': ARKA_PLAN_RENGI, 'activebackground': "#ACACAC", 'width': 12, 'height': 3})
        
        parametreler2 = {'command': lambda: self.secenek_sec("baslangic_buton2", self.buton_widgetler['baslangic_buton2']), 'relief': tk.FLAT, 'bd': 0}
        if 'ana_buton2_normal' in self.buton_fotolari:
            parametreler2.update({'image': self.buton_fotolari['ana_buton2_normal'], 'bg': ARKA_PLAN_RENGI, 'activebackground': ARKA_PLAN_RENGI})
        else:
            parametreler2.update({'text': BASLANGIC_SECENEKLERI['baslangic_buton2'], 'font': ("Georgia", 28, "bold"), 'fg': "#3A3A3A", 'bg': ARKA_PLAN_RENGI, 'activebackground': "#ACACAC", 'width': 12, 'height': 3})
            
        self.buton_widgetler['baslangic_buton1'] = tk.Button(self.ana, **parametreler1)
        self.buton_widgetler['baslangic_buton2'] = tk.Button(self.ana, **parametreler2)
        
        parametreler3 = {'command': self.ekstra_bilgi_ac, 'relief': tk.FLAT, 'bd': 0}
        if 'ekstra_bilgi_normal' in self.buton_fotolari:
            parametreler3.update({'image': self.buton_fotolari['ekstra_bilgi_normal'], 'bg': ARKA_PLAN_RENGI, 'activebackground': ARKA_PLAN_RENGI})
        else:
             parametreler3.update({'text': "Yapım Ekibi", 'font': ("Georgia", 12, "bold"), 'fg': "white", 'bg': "#3498DB", 'activebackground': "#2980B9", 'width': 10, 'height': 2})
        
        self.buton_widgetler['ekstra_bilgi'] = tk.Button(self.ana, **parametreler3)
        self.buton_pozisyonlari = {
            'baslangic_buton1': (X1, hedef_y),
            'baslangic_buton2': (X2, hedef_y),
            'ekstra_bilgi': (X_KOSESI, Y_KOSESI), 
            'baslik': (MERKEZ_X, MERKEZ_Y - 250)
        }
        self.secenek_pencereleri = {}
        self.secenek_pencereleri['baslangic_buton1'] = self.tuval.create_window(X1, baslangic_y, window=self.buton_widgetler['baslangic_buton1'])
        self.secenek_pencereleri['baslangic_buton2'] = self.tuval.create_window(X2, baslangic_y, window=self.buton_widgetler['baslangic_buton2'])
        self.secenek_pencereleri['ekstra_bilgi'] = self.tuval.create_window(X_KOSESI, baslangic_y, window=self.buton_widgetler['ekstra_bilgi'])
        self.baslik_id = self.tuval.create_text(self.buton_pozisyonlari['baslik'][0], baslangic_y, text="Nerde Yemek İstersiniz?", fill="#333333", font=("Georgia", 48, "bold"), tags="baslik_yazi")

    def _kapatilirken(self):
        self.video_oynuyor = False
        if self.yakalama.isOpened(): self.yakalama.release()
        self.ana.destroy()

    def kareyi_guncelle(self):
        if not self.video_oynuyor: return
        ret, kare = self.yakalama.read()
        if ret:
            cv_gorsel = cv2.cvtColor(kare, cv2.COLOR_BGR2RGB)
            pil_gorsel = Image.fromarray(cv_gorsel).resize((self.ekran_genisligi, self.ekran_yuksekligi))
            self.tk_gorsel = ImageTk.PhotoImage(image=pil_gorsel)
            self.tuval.delete("video_kare")
            self.tuval.create_image(0, 0, image=self.tk_gorsel, anchor=tk.NW, tags="video_kare")
            self.tuval.tag_lower("video_kare") 
        else:
            self.yakalama.set(cv2.CAP_PROP_POS_FRAMES, 0)
        if self.ana.winfo_exists():
            self.ana.after(FPS, self.kareyi_guncelle)

    def videoya_geri_don(self):
        self.menu_aktif = False
        self.ekstra_bilgi_aktif = False
        if self.zaman_asimi_job:
            self.ana.after_cancel(self.zaman_asimi_job)
            self.zaman_asimi_job = None
        for widget in self.ana.winfo_children():
            if isinstance(widget, tk.Toplevel):
                widget.destroy()
        if not self.video_oynuyor:
            self.video_oynuyor = True
            baslangic_y = self.ekran_yuksekligi * 2
            self.tuval.coords(self.baslik_id, self.buton_pozisyonlari['baslik'][0], baslangic_y)
            self.tuval.coords(self.secenek_pencereleri['baslangic_buton1'], self.buton_pozisyonlari['baslangic_buton1'][0], baslangic_y)
            self.tuval.coords(self.secenek_pencereleri['ekstra_bilgi'], self.buton_pozisyonlari['ekstra_bilgi'][0], baslangic_y)
            self.tuval.coords(self.secenek_pencereleri['baslangic_buton2'], self.buton_pozisyonlari['baslangic_buton2'][0], baslangic_y)
            self.tuval.config(bg="black")
            self.ana.deiconify() 
            self.kareyi_guncelle()
        else:
            self.ana.deiconify()
    
    def ekstra_bilgi_ac(self):
        self.zaman_asimi_sifirla()
        self.ekstra_bilgi_aktif = True 
        EkstraBilgiSayfasi(self.ana, self)

    def tiklama_isle(self, olay):
        if not self.menu_aktif:
            self.menu_aktif, self.video_oynuyor = True, False
            self.tuval.delete("video_kare")
            self.tuval.config(bg=ARKA_PLAN_RENGI)
            hedef_x1, hedef_y1 = self.buton_pozisyonlari['baslangic_buton1']
            self.tuval.coords(self.secenek_pencereleri['baslangic_buton1'], hedef_x1, hedef_y1)
            hedef_x_ekstra, hedef_y_ekstra = self.buton_pozisyonlari['ekstra_bilgi']
            self.tuval.coords(self.secenek_pencereleri['ekstra_bilgi'], hedef_x_ekstra, hedef_y_ekstra)
            hedef_x2, hedef_y2 = self.buton_pozisyonlari['baslangic_buton2']
            self.tuval.coords(self.secenek_pencereleri['baslangic_buton2'], hedef_x2, hedef_y2)
            hedef_x_b, hedef_y_b = self.buton_pozisyonlari['baslik']
            self.tuval.coords(self.baslik_id, hedef_x_b, hedef_y_b)
            self.zaman_asimi_sifirla()
            
    def secenek_sec(self, secenek_id, buton_widgetler):
        self.secili_baslangic_secenek = secenek_id
        if secenek_id in ["baslangic_buton1", "baslangic_buton2"]:
            self.zaman_asimi_sifirla()
            ikinci_sayfa = MenuSecimPenceresi(self.ana, self)
            ikinci_sayfa.lift()
            ikinci_sayfa.focus_force() 

if __name__ == "__main__":
    if not os.path.exists(VIDEO_DOSYA):
        print(f"HATA: '{VIDEO_DOSYA}' video dosyası bulunamadı.")
    kok = tk.Tk()
    uygulama = KioskUygulamasi(kok)
    kok.mainloop()